module.exports.userController = require("./user.controller");
module.exports.productController=require("./product.controller");
module.exports.vendorController=require("./vendor.controller");
module.exports.authController= require("./auth.controller");
