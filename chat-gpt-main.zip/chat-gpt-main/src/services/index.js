module.exports.authService = require("./auth.service");
module.exports.userService = require("./user.service");
module.exports.tokenService = require("./token.service");
module.exports.productService = require("./product.services");
module.exports.vendorService = require("./vendor.service");
module.exports.openAiService = require("./openai.service");
