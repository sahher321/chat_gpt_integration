const roles = ["superadmin", "admin"];

module.exports = {
  roles,
};
