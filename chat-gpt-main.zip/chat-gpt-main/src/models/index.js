module.exports.User = require("./user.model");
module.exports.Product = require("./product.model");
module.exports.Vendor =require("./vendor.model");

